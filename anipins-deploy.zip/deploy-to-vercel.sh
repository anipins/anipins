#!/bin/bash

# ============================================
# Deploy AniPins to anipins-three.vercel.app
# ============================================

echo "🚀 AniPins Deployment Script"
echo "============================"
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: Run this from /home/user/anipins"
    exit 1
fi

# Step 1: Build
echo "📦 Building project..."
npm run build
if [ $? -ne 0 ]; then
    echo "❌ Build failed! Fix errors above."
    exit 1
fi
echo "✅ Build successful"
echo ""

# Step 2: Check for .env.local
if [ ! -f ".env.local" ]; then
    echo "⚠️  No .env.local found!"
    echo ""
    echo "Create .env.local with:"
    echo "------------------------"
    echo "NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co"
    echo "NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key"
    echo "SUPABASE_SERVICE_ROLE_KEY=your-service-role-key"
    echo "NEXTAUTH_SECRET=$(openssl rand -base64 32)"
    echo "NEXTAUTH_URL=https://anipins-three.vercel.app"
    echo ""
    read -p "Press Enter after creating .env.local..."
fi

# Step 3: Login check
echo "🔑 Checking Vercel login..."
vercel whoami 2>/dev/null
if [ $? -ne 0 ]; then
    echo "Please login to Vercel:"
    vercel login
fi

# Step 4: Deploy
echo ""
echo "📤 Deploying to Vercel..."
echo ""

# Link to existing project (anipins-three)
vercel link --yes --project anipins --scope $(vercel whoami 2>/dev/null | head -1)

# Deploy to production
echo ""
echo "🚀 Deploying to production..."
vercel --prod --yes

echo ""
echo "✅ Deployment complete!"
echo "🌐 Visit: https://anipins-three.vercel.app/"
echo ""
echo "Next steps:"
echo "1. Check your site: https://anipins-three.vercel.app/"
echo "2. Test login: anipins01@gmail.com / anipins2024!"
echo "3. Check admin dashboard"
